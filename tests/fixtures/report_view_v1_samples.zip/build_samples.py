"""Deterministically rebuild the Report View 1.0 design-review samples."""

from __future__ import annotations

import copy
import hashlib
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

from modules.report_view import (
    _privacy,
    _source_reference,
    _status,
    build_report_view,
    canonical_report_view_bytes,
)
from modules.report_view_validation import validate_report_view_document


HERE = Path(__file__).resolve().parent
SCHEMA = HERE.parent / "resources" / "schemas" / "report_view-1.0.schema.json"
RETAINED_SAMPLE_NAMES = (
    "small-complete-local.json",
    "medium-partial-multilanguage.json",
    "protected-check-and-ratchet.json",
    "all-supplements-admitted.json",
    "missing-refused-unavailable.json",
    "large-row-population.json",
)
HISTORICAL_REFUSAL_SAMPLE_NAME = "missing-refused-unavailable.json"
CORRECTED_REFUSAL_SAMPLE_NAME = "supplied-refused-unavailable-corrected.json"
SAMPLE_NAMES = RETAINED_SAMPLE_NAMES + (CORRECTED_REFUSAL_SAMPLE_NAME,)

# These six payloads are retained, cited historical design evidence. Generator
# maintenance must not change their bytes; new scenarios are added separately.
RETAINED_SAMPLE_SHA256 = {
    "small-complete-local.json": "7505d6b61b52317683b83c6ef9c4f09312b375ab615a76cf6e35a4ae85cca418",
    "medium-partial-multilanguage.json": "d2849fa60e45487234b4d3ca7ede0e91580a272d6a2d3fa3481b67024ad29e9b",
    "protected-check-and-ratchet.json": "b203803fbb3b638cf76dbffa32514edc4af1d6bdf0a0a65c7f4a04fc002e7c81",
    "all-supplements-admitted.json": "3fdd363dd012b5beeedebfa96605b4057905ebb2c419a8614cdfc76243d10f7a",
    "missing-refused-unavailable.json": "08fdb1641047a6f12b294aa10a0eaecf5cfb013c268dea910e652672fe8ee67f",
    "large-row-population.json": "91e96159969ea7f06b88f602a389955f31a591502077068d7c1fb16c2b1b0ef1",
}


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


class _Reader:
    def __init__(self, root: Path): self.root = root
    def document_bytes(self, relative: str) -> bytes: return (self.root / relative).read_bytes()


class _FixtureView:
    def __init__(self, root: Path, *, fixture: str, languages: int, callables: int, partial: bool, diagnostic: bool):
        self.run_directory = root
        self.run_id = f"sample-{_digest(fixture)[:12]}"
        self.integrity_status = "completed_with_errors" if partial else "completed"
        self.finalized = True
        self.lifecycle = SimpleNamespace(value="finalized_valid")
        self.compatibility = SimpleNamespace(state=SimpleNamespace(value="supported"))
        self.manifest = {
            "run_id": self.run_id, "product_name": "ArchLens", "program_version": "3.8.0",
            "artifact_schema_version": "1.12.0", "metric_contract_version": "3.0.0",
            "complexity_contract_version": "2.0.0", "exclusion_policy_version": "1.5.0",
            "inventory_schema_version": "1.7.0", "profiler_provenance_kind": "installed_distribution",
            "profiler_source_sha256": _digest("synthetic-evaluator"), "profiler_git_state": "not_applicable",
            "profiler_git_dirty": None, "execution_mode": "metrics",
        }
        self.status = {"run_id": self.run_id, "status": self.integrity_status, "measurement_outcome": "partial" if partial else "complete"}
        self.environment = {"archlens_version": "3.8.0"}
        subject = f"sample:{fixture}"
        aggregate_status = "partial" if partial else "complete"
        self.repositories = ({
            "subject_key": subject, "subject_key_portable": True, "subject_key_basis": "explicit",
            "repository_url": None, "architecture_type": "unknown", "architecture_type_source": "synthetic_fixture",
            "analysis_status": aggregate_status, "core_metric_status": aggregate_status,
            "metric_contract_version": "3.0.0", "analysis_scope_hash": "sha256:" + _digest(f"scope:{fixture}"),
            "acquisition": {"analyzed_commit_sha": _digest(f"revision:{fixture}")[:40]},
            "metrics": {
                "aggregate": {
                    "source_files": languages * 5, "lines_of_code": callables * 7,
                    "classes_structs": callables // 4, "methods_functions": callables,
                    "source_files_status": aggregate_status, "loc_status": aggregate_status,
                    "classes_structs_status": aggregate_status, "methods_functions_status": aggregate_status,
                },
                "source_files_by_language": {f"Language-{index:02d}": 5 for index in range(languages)},
                "complexity": {
                    "status": aggregate_status, "cognitive_measurement_state": "measured",
                    "aggregate": {"callable_count": callables, "cyclomatic_complexity_max": 12, "cyclomatic_complexity_mean": 3.5},
                },
            },
        },)
        self.language_metrics = tuple({
            "subject_key": subject, "language": f"language-{index:02d}",
            "source_files": 5, "lines_of_code": callables * 7 // languages,
            "classes_structs": callables // max(1, 4 * languages), "methods_functions": callables // languages,
            "source_files_status": aggregate_status, "loc_status": aggregate_status,
            "classes_structs_status": aggregate_status, "methods_functions_status": aggregate_status,
            "metric_status": aggregate_status,
        } for index in range(languages))
        self.sheet_metrics = ()
        self._callables = tuple({
            "subject_key": subject, "detected_language": f"Language-{index % languages:02d}",
            "relative_path": f"src/file-{index // 20:05d}.py", "callable_row_id": "sha256:" + _digest(f"{fixture}:callable:{index}"),
            "qualified_name": f"Fixture.method_{index:06d}", "start_line": index % 20 * 5 + 1,
            "end_line": index % 20 * 5 + 4, "nloc": 4, "cyclomatic_complexity": index % 12 + 1,
            "cognitive_complexity": index % 17, "max_nesting_depth": index % 5,
            "formal_parameter_count": index % 7, "structural_complexity_status": aggregate_status,
            "nloc_status": aggregate_status,
        } for index in range(callables))
        self.has_callable_artifact = True
        self.errors = (() if not diagnostic else ({
            "subject_key": subject, "detected_language": "Language-00", "file_path": "src/excluded.generated.py",
            "error_category": "exclusion", "error_type": "generated_file", "severity": "information",
            "message": "generated source excluded by the recorded exclusion policy",
        },))
        self.recoveries = ()
        self.reader = _Reader(root)

    def stream_callables(self): yield from self._callables


def _write_sources(root: Path, view: _FixtureView) -> None:
    root.mkdir(parents=True, exist_ok=True)
    for relative, value in {
        "run_manifest.json": view.manifest, "run_status.json": view.status,
        "environment.json": view.environment, "analysis.json": list(view.repositories),
    }.items():
        (root / relative).write_text(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8", newline="\n")
    for relative, text in {
        "sheet_metrics.csv": "subject_key\n", "language_metrics.csv": "subject_key,language\n",
        "callables.csv": "callable_row_id\n", "errors.csv": "subject_key,message\n",
        "recoveries.csv": "subject_key,message\n", "catalog.csv": "subject_key\n",
    }.items():
        (root / relative).write_text(text, encoding="utf-8", newline="\n")


def _base(work: Path, name: str, *, languages: int, callables: int, partial: bool = False, diagnostic: bool = False):
    root = work / name
    view = _FixtureView(root, fixture=name, languages=languages, callables=callables, partial=partial, diagnostic=diagnostic)
    _write_sources(root, view)
    document = build_report_view(view)
    document["document_identity"]["sample_classification"] = "synthetic_design_fixture"
    document["document_identity"]["sample_fixture_identity"] = f"report-view-v1:{name}"
    return document


def _add_source(document, role, format_name, version):
    source = {
        "role": role, "format": format_name, "format_version": version,
        "sha256": _digest(f"report-view-v1:{role}:{format_name}:{version}"),
        "portable_path": f"synthetic/{role}.json", "subject_key": None,
    }
    document["source_documents"].append(source)
    document["source_documents"].sort(key=lambda row: (row["role"], row["portable_path"]))
    return source


def _ref(source, row_id, pointer):
    return _source_reference(source, row_id=row_id, pointer=pointer)


def _set_admission(document, kind, state, source=None, *, synchronize_section=True):
    row = next(item for item in document["supplement_admission"] if item["kind"] == kind)
    row.update({
        "supplied": state != "not_supplied", "state": _status(state, vocabulary="synthetic_fixture", axis="admission"),
        "document_format": source["format"] if source else None,
        "document_format_version": source["format_version"] if source else None,
        "detail": None if state == "admitted" else f"synthetic {state} admission fixture",
        "matched_subject_keys": [document["subjects"][0]["subject_key"]] if state == "admitted" else [],
        "contributes_evidence": state == "admitted", "source_reference": _ref(source, None, "/") if source else None,
    })
    section_name = {"changed": "changed_code", "duplication": "duplication", "hotspots": "hotspots"}.get(kind)
    if synchronize_section and section_name is not None and state != "admitted":
        document[section_name]["availability"] = _status(
            state,
            vocabulary="supplement_admission",
            axis="admission",
        )


def _finding(document, source, finding_id, status="violated"):
    return {
        "finding_id": finding_id, "rule_id": "fixture.rule", "metric": "repository.lines_of_code",
        "scope": "repository", "subject_key": document["subjects"][0]["subject_key"], "language": None,
        "status": _status(status, vocabulary="synthetic_check_result", axis="policy", reason_code=None if status == "violated" else "measurement_unavailable"),
        "severity": "warning", "message": "Synthetic contract finding for design review.",
        "observed_value": 42 if status == "violated" else None, "operator": "gt", "threshold": 40,
        "reason": None if status == "violated" else "measurement_unavailable",
        "location": {"relative_path": None, "start_line": None, "end_line": None},
        "related_locations": [], "evidence_keys": [], "source_reference": _ref(source, finding_id, "/findings/0"),
    }


def _admit_policy(document, *, protected: bool, ratchet: bool, not_evaluable: bool = False):
    source = _add_source(document, "policy_result", "archlens-check-result", "1.4.0")
    _set_admission(document, "policy_result", "admitted", source)
    finding = _finding(document, source, "alf1:" + _digest("fixture-finding")[:32], "not_evaluable" if not_evaluable else "violated")
    document["findings"] = {
        "evaluation": _status("violated" if not not_evaluable else "error", vocabulary="synthetic_check_result", axis="policy"),
        "check_result_identity": {"format": "archlens-check-result", "format_version": "1.4.0"},
        "verdict": "fail" if not not_evaluable else "error", "exit_code": 1 if not not_evaluable else 2,
        "failure_kind": None if not not_evaluable else "not_evaluable",
        "policy_identity": {"name": "Synthetic review policy", "format_version": "2.2.0"},
        "policy_digest": _digest("synthetic-policy"), "trust_mode": "protected_required" if protected else "local_unprotected",
        "counts": [{"name": "findings", "value": 1}, {"name": "failing", "value": 1}],
        "canonical_findings": [] if not_evaluable else [finding], "not_evaluable": [finding] if not_evaluable else [],
        "waived_findings": [],
        "ratchet": {
            "configured": ratchet, "status": "evaluated" if ratchet else "not_configured",
            "admission_status": "admitted" if ratchet else "not_requested", "evaluated_count": 1 if ratchet else 0,
            "violated_count": 1 if ratchet else 0, "not_evaluable_count": 0, "paired_subject_count": 1 if ratchet else 0,
            "baseline_format": "archlens-ratchet-baseline" if ratchet else None,
            "baseline_format_version": "1.0.0" if ratchet else None,
            "baseline_digest": _digest("synthetic-baseline") if ratchet else None,
            "baseline_source_run_id": "sample-baseline" if ratchet else None,
            "source_reference": _ref(source, None, "/ratchet"),
        },
        "source_reference": _ref(source, None, "/"),
    }
    if protected:
        trust = document["trust_and_reproducibility"]
        trust.update({
            "gate_mode": "protected_required", "trust_status": _status("protected_required", vocabulary="synthetic_check_result", axis="trust"),
            "policy_digest": _digest("synthetic-policy"), "policy_trust": "externally_authenticated",
            "trusted_evidence_receipt": {"sha256": _digest("synthetic-receipt"), "format": "archlens-trusted-evidence-receipt", "format_version": "1.0.0"},
            "ratchet_baseline_digest": _digest("synthetic-baseline") if ratchet else None,
        })
        trust["evaluator_identity"]["trust"] = "externally_authenticated"
    return source


def _admit_all_supplements(document):
    policy = _admit_policy(document, protected=True, ratchet=True)
    duplication = _add_source(document, "duplication", "archlens-duplication", "1.0.0")
    hotspots = _add_source(document, "hotspots", "archlens-hotspots", "1.0.0")
    changed = _add_source(document, "changed", "archlens-changed-code", "1.0.0")
    for kind, source in (("duplication", duplication), ("hotspots", hotspots), ("changed", changed)):
        _set_admission(document, kind, "admitted", source)
    occurrence = {
        "occurrence_id": "do1:" + _digest("occurrence"), "relative_path": "src/duplicate.py",
        "start_line": 10, "end_line": 20, "duplicated_nloc": 11,
        "source_reference": _ref(duplication, "do1:" + _digest("occurrence"), "/lexical_groups/0/occurrences/0"),
    }
    document["duplication"] = {
        "availability": _status("complete", vocabulary="synthetic_duplication", axis="measurement"),
        "identities": [{"name": "format", "value": "archlens-duplication"}, {"name": "format_version", "value": "1.0.0"}, {"name": "analysis_contract_version", "value": "1.0.0"}],
        "requested_kinds": ["lexical", "structural"], "candidate_thresholds": [{"name": "minimum_duplicated_nloc", "value": 6}],
        "counts": [{"name": "lexical.group_count", "value": 1}, {"name": "lexical.occurrence_count", "value": 1}, {"name": "structural.retained_group_count", "value": 0}],
        "groups": [{"kind": "lexical", "group_id": "dg1:" + _digest("group"), "fingerprint": "sha256:" + _digest("fingerprint"), "language": "python", "occurrence_count": 1, "file_count": 1, "occurrences": [occurrence], "source_reference": _ref(duplication, "dg1:" + _digest("group"), "/lexical_groups/0")}],
        "limitations": ["synthetic fixture; no defect claim and no score"], "source_reference": _ref(duplication, None, "/"),
    }
    subject = document["subjects"][0]["subject_key"]
    document["hotspots"] = {
        "availability": _status("complete", vocabulary="synthetic_hotspots", axis="measurement"),
        "identities": [{"name": "format", "value": "archlens-hotspots"}, {"name": "format_version", "value": "1.0.0"}],
        "counts": [{"name": "row_count", "value": 1}, {"name": "attention.high_attention", "value": 1}, {"name": "attention.low_attention", "value": 0}, {"name": "attention.moderate_attention", "value": 0}, {"name": "attention.unclassified", "value": 0}],
        "rows": [{"subject_key": subject, "relative_path": "src/hot.py", "language": "python", "complexity_status": "measured", "complexity_value": 21, "complexity_signal": "high", "churn_status": "measured", "churn_value": 8, "churn_signal": "high", "attention_class": "high_attention", "reasons": ["synthetic independently retained complexity and churn signals"], "source_reference": _ref(hotspots, f"{subject}:src/hot.py", "/hotspots/0")}],
        "limitations": ["attention is not defect probability and is not a score"], "source_reference": _ref(hotspots, None, "/"),
    }
    hunk = {"ordinal": 1, "base_start_line": 10, "base_line_count": 2, "head_start_line": 10, "head_line_count": 3, "added_lines": 3, "deleted_lines": 2, "source_reference": _ref(changed, "fcc1_fixture:hunk:1", "/file_changes/0/hunks/items/0")}
    document["changed_code"] = {
        "availability": _status("complete", vocabulary="synthetic_changed", axis="measurement"),
        "identity": {"format": "archlens-changed-code", "format_version": "1.0.0", "base_revision": _digest("base")[:40], "head_revision": document["subjects"][0]["analyzed_revision"], "repository_subject_key": subject},
        "comparability": [{"name": "metric_contracts_equal", "value": True}],
        "counts": [{"name": "git_changed_files", "value": 1}, {"name": "added_diff_lines", "value": 3}, {"name": "deleted_diff_lines", "value": 2}],
        "files": [{"file_change_id": "fcc1_fixture", "change_classification": "modified", "base_path": "src/app.py", "head_path": "src/app.py", "scope": "changed_code", "hunks": [hunk], "source_reference": _ref(changed, "fcc1_fixture", "/file_changes/0")}],
        "limitations": ["side-local callable evidence only; no diff body"], "source_reference": _ref(changed, None, "/"),
    }
    return policy, duplication, hotspots, changed


def _large(document):
    _admit_all_supplements(document)
    duplication_source = next(row for row in document["source_documents"] if row["role"] == "duplication")
    hotspot_source = next(row for row in document["source_documents"] if row["role"] == "hotspots")
    changed_source = next(row for row in document["source_documents"] if row["role"] == "changed")
    document["duplication"]["groups"] = []
    for index in range(120):
        group_id = "dg1:" + _digest(f"large-group:{index}")
        occurrences = [{
            "occurrence_id": "do1:" + _digest(f"large-occurrence:{index}:{ordinal}"),
            "relative_path": f"src/dup-{index:04d}-{ordinal}.py", "start_line": 1, "end_line": 8,
            "duplicated_nloc": 8, "source_reference": _ref(duplication_source, "do1:" + _digest(f"large-occurrence:{index}:{ordinal}"), f"/lexical_groups/{index}/occurrences/{ordinal}"),
        } for ordinal in range(3)]
        document["duplication"]["groups"].append({
            "kind": "lexical" if index % 2 == 0 else "structural", "group_id": group_id,
            "fingerprint": "sha256:" + _digest(f"large-fingerprint:{index}"), "language": "python",
            "occurrence_count": 3, "file_count": 3, "occurrences": occurrences,
            "source_reference": _ref(duplication_source, group_id, f"/lexical_groups/{index}"),
        })
    document["duplication"]["counts"] = [
        {"name": "lexical.group_count", "value": 60},
        {"name": "lexical.occurrence_count", "value": 180},
        {"name": "structural.retained_group_count", "value": 60},
        {"name": "structural.occurrence_count", "value": 180},
    ]
    subject = document["subjects"][0]["subject_key"]
    document["hotspots"]["rows"] = [{
        "subject_key": subject, "relative_path": f"src/hot-{index:04d}.py", "language": "python",
        "complexity_status": "measured", "complexity_value": index % 40, "complexity_signal": ("high", "medium", "low")[index % 3],
        "churn_status": "measured", "churn_value": index % 20, "churn_signal": ("low", "medium", "high")[index % 3],
        "attention_class": ("low_attention", "moderate_attention", "high_attention")[index % 3],
        "reasons": ["synthetic scale row"], "source_reference": _ref(hotspot_source, f"{subject}:src/hot-{index:04d}.py", f"/hotspots/{index}"),
    } for index in range(500)]
    document["hotspots"]["counts"] = [
        {"name": "row_count", "value": 500},
        {"name": "attention.high_attention", "value": 166},
        {"name": "attention.low_attention", "value": 167},
        {"name": "attention.moderate_attention", "value": 167},
        {"name": "attention.unclassified", "value": 0},
    ]
    document["changed_code"]["files"] = [{
        "file_change_id": f"fcc1_{index:06d}", "change_classification": "modified",
        "base_path": f"src/change-{index:04d}.py", "head_path": f"src/change-{index:04d}.py", "scope": "changed_code",
        "hunks": [{"ordinal": 1, "base_start_line": 1, "base_line_count": 2, "head_start_line": 1, "head_line_count": 3, "added_lines": 3, "deleted_lines": 2, "source_reference": _ref(changed_source, f"fcc1_{index:06d}:hunk:1", f"/file_changes/{index}/hunks/items/0")}],
        "source_reference": _ref(changed_source, f"fcc1_{index:06d}", f"/file_changes/{index}"),
    } for index in range(250)]
    document["changed_code"]["counts"] = [
        {"name": "git_changed_files", "value": 250},
        {"name": "added_diff_lines", "value": 750},
        {"name": "deleted_diff_lines", "value": 500},
    ]


def _finalize(document):
    document["privacy_inventory"] = _privacy(document)
    validate_report_view_document(document)
    return canonical_report_view_bytes(document)


def _configure_refusal_and_missingness(document, *, preserve_historical_availability=False):
    _admit_policy(document, protected=False, ratchet=False, not_evaluable=True)
    refused_version = "9.9.9" if preserve_historical_availability else "1.0.0"
    refused = _add_source(
        document, "duplication", "archlens-duplication", refused_version
    )
    _set_admission(
        document,
        "duplication",
        "refused",
        refused,
        synchronize_section=not preserve_historical_availability,
    )
    if not preserve_historical_availability:
        detail = (
            "synthetic active-contract document rejected by its independent "
            "validator"
        )
        admission = next(
            row
            for row in document["supplement_admission"]
            if row["kind"] == "duplication"
        )
        admission["detail"] = detail
        admission["state"] = _status(
            "refused",
            vocabulary="supplement_admission",
            axis="admission",
            reason_code="refused",
            reason_text=detail,
        )
    first = document["measurements"]["core_metrics"][0]
    first.update({"value": None, "status": _status("unavailable", vocabulary="synthetic_fixture", axis="measurement", reason_code="fixture_unavailable")})
    second = document["measurements"]["core_metrics"][1]
    second.update({"value": None, "status": _status("not_applicable", vocabulary="synthetic_fixture", axis="measurement")})
    third = document["measurements"]["core_metrics"][2]
    third.update({"value": 0, "status": _status("partial", vocabulary="synthetic_fixture", axis="measurement", value=0)})


def build_all() -> dict[str, bytes]:
    with tempfile.TemporaryDirectory(prefix="archlens-report-view-samples-") as directory:
        work = Path(directory)
        small = _base(work, "small-complete-local", languages=2, callables=12)
        medium = _base(work, "medium-partial-multilanguage", languages=5, callables=240, partial=True, diagnostic=True)
        protected = _base(work, "protected-check-and-ratchet", languages=3, callables=80)
        _admit_policy(protected, protected=True, ratchet=True)
        all_supplements = _base(work, "all-supplements-admitted", languages=4, callables=160)
        _admit_all_supplements(all_supplements)
        missing = _base(work, "missing-refused-unavailable", languages=2, callables=20, partial=True, diagnostic=True)
        # Preserve this known contradictory projection exactly: it is retained
        # historical evidence, not the generator behavior for future fixtures.
        _configure_refusal_and_missingness(missing, preserve_historical_availability=True)
        large = _base(work, "large-row-population", languages=6, callables=2500, partial=True, diagnostic=True)
        _large(large)
        corrected = _base(work, "supplied-refused-unavailable-corrected", languages=2, callables=20, partial=True, diagnostic=True)
        _configure_refusal_and_missingness(corrected)
        documents = {
            SAMPLE_NAMES[0]: small, SAMPLE_NAMES[1]: medium, SAMPLE_NAMES[2]: protected,
            SAMPLE_NAMES[3]: all_supplements, SAMPLE_NAMES[4]: missing, SAMPLE_NAMES[5]: large,
            CORRECTED_REFUSAL_SAMPLE_NAME: corrected,
        }
        payloads = {name: _finalize(document) for name, document in documents.items()}
        for name, expected_sha256 in RETAINED_SAMPLE_SHA256.items():
            actual_sha256 = hashlib.sha256(payloads[name]).hexdigest()
            if actual_sha256 != expected_sha256:
                raise AssertionError(f"retained sample changed: {name}: {actual_sha256}")
        return payloads


def _coverage(document):
    statuses = sorted({
        value.get("presentation_code")
        for location, value in _walk(document)
        if not location.startswith("/presentation_vocabulary")
        if isinstance(value, dict) and "presentation_code" in value
    })
    return [value for value in statuses if value is not None]


def _walk(value, location=""):
    yield location, value
    if isinstance(value, dict):
        for key, child in value.items(): yield from _walk(child, f"{location}/{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value): yield from _walk(child, f"{location}/{index}")


def main() -> None:
    payloads = build_all()
    entries = []
    for name in SAMPLE_NAMES:
        payload = payloads[name]
        sample_path = HERE / name
        if name == HISTORICAL_REFUSAL_SAMPLE_NAME:
            retained_payload = sample_path.read_bytes()
            retained_sha256 = hashlib.sha256(retained_payload).hexdigest()
            if retained_sha256 != RETAINED_SAMPLE_SHA256[name] or retained_payload != payload:
                raise AssertionError(f"retained historical sample does not match its frozen bytes: {name}")
            payload = retained_payload
        else:
            sample_path.write_bytes(payload)
        document = json.loads(payload)
        entry = {
            "name": name, "sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload),
            "fixture_classification": document["document_identity"]["sample_classification"],
            "subject_count": len(document["subjects"]),
            "language_count": len(document["measurements"]["language_metrics"]),
            "callable_count": len(document["measurements"]["callable_records"]),
            "finding_count": len(document["findings"]["canonical_findings"]) + len(document["findings"]["not_evaluable"]),
            "duplication_group_count": len(document["duplication"]["groups"]),
            "duplication_occurrence_count": sum(len(group["occurrences"]) for group in document["duplication"]["groups"]),
            "hotspot_row_count": len(document["hotspots"]["rows"]),
            "changed_file_count": len(document["changed_code"]["files"]),
            "changed_hunk_count": sum(len(row["hunks"]) for row in document["changed_code"]["files"]),
            "covered_statuses": _coverage(document),
            "trust_states": [document["trust_and_reproducibility"]["gate_mode"]],
        }
        if name == HISTORICAL_REFUSAL_SAMPLE_NAME:
            entry.update({
                "fixture_role": "retained_historical_design_evidence",
                "known_inconsistency": "duplication is supplied and refused while section availability says not_supplied",
                "explorer_refusal_missingness_use": "historical_evidence_only",
            })
        elif name == CORRECTED_REFUSAL_SAMPLE_NAME:
            entry.update({
                "fixture_role": "corrected_synthetic_design_fixture",
                "corrects_historical_sample": HISTORICAL_REFUSAL_SAMPLE_NAME,
                "explorer_refusal_missingness_use": "future_design_and_testing",
            })
        entries.append(entry)
    manifest = {
        "format": "archlens-report-view-sample-manifest", "format_version": "1.0.0",
        "report_view_format_version": "1.0.0", "samples": entries,
    }
    (HERE / "SAMPLES.json").write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    (HERE / "report_view-1.0.schema.json").write_bytes(SCHEMA.read_bytes())


if __name__ == "__main__": main()
